cd /home/pavani/Desktop/DailyUserLogArchiver/
git init
git add 
log_archiver.sh README.md
git commit -m "Final project files and documentation"
# Link to your GitHub repo and push (use your actual repo URL)
# Example: git remote add origin https://github.com/yourusername/midterm-project.git
#          git push -u origin main

